import React, { createContext, useContext, useState } from 'react';

const FloatingContext = createContext<{
    floating: boolean;
    setFloating: (v: boolean) => void;
}>({
    floating: false,
    setFloating: () => undefined,
});

export const FloatingProvider: React.FC = ({ children }) => {
    const [floating, setFloating] = useState(false);
    // 6e47c645a41c9b9ff940615db895f8cdb9045d7f427e58aa1d794b4d8101ae58

    return <FloatingContext.Provider value={{ floating, setFloating }}>{children}</FloatingContext.Provider>;
};

export const useFloating = () => useContext(FloatingContext);
