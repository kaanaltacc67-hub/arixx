<?php

namespace Pterodactyl\Console\Commands;

use Illuminate\Console\Command;
use Symfony\Component\Console\Formatter\OutputFormatterStyle;
use Illuminate\Support\Facades\File;

class Arix extends Command
{
    protected $signature = 'arix {action?}';
    protected $description = 'All commands for Arix Theme for Pterodactyl.';

    public function handle()
    {
        $action = $this->argument('action');

        $title = new OutputFormatterStyle('#fff', null, ['bold']);
        $this->output->getFormatter()->setStyle('title', $title);

        $b = new OutputFormatterStyle(null, null, ['bold']);
        $this->output->getFormatter()->setStyle('b', $b);

        if ($action === null) {
            $this->line("
            <title>
            ░█████╗░██████╗░██╗██╗░░██╗
            ██╔══██╗██╔══██╗██║╚██╗██╔╝
            ███████║██████╔╝██║░╚███╔╝░
            ██╔══██║██╔══██╗██║░██╔██╗░
            ██║░░██║██║░░██║██║██╔╝╚██╗
            ╚═╝░░╚═╝╚═╝░░╚═╝╚═╝╚═╝░░╚═╝

           Thank you for purchasing Arix</title>

           > php artisan arix
           > php artisan arix install
           > php artisan arix uninstall
            ");
        } elseif ($action === 'install') {
            $this->install();
        } elseif ($action === 'uninstall') {
            $this->uninstall();
        } else {
            $this->error("Invalid action. Supported actions: install, uninstall");
        }
    }

    public function installOrUpdate()
    {
        // Automatically confirm YES.
        $confirmation = true;

        if (!$confirmation) {
            return;
        }

        // Check required dependencies.
        foreach (['node', 'yarn', 'rsync'] as $bin) {
            exec('command -v ' . escapeshellarg($bin), $out, $code);

            if ($code !== 0) {
                $this->error("Required program not found: {$bin}. Install it and run again.");
                return;
            }
        }

        // Find available versions.
        $versions = File::directories('./arix');

        if (empty($versions)) {
            $this->info('No versions found in /arix directory.');
            return;
        }

        // Always select version 0.
        $versionPath = base_path('arix/0');

        if (!File::isDirectory($versionPath)) {
            $this->error('Version 0 not found in /arix directory.');
            return;
        }

        $version = '0';

        $this->info("Installing Arix Theme {$version}...");

        if (!$this->shell("rsync -a " . escapeshellarg($versionPath . '/') . " ./")) {
            $this->error('Copying theme files failed.');
            return;
        }

        $directoryPath = app_path('Http/Controllers/Admin/Arix');

        File::makeDirectory($directoryPath, 0755, true, true);

        $this->info('Proceeding with the installation...');

        $this->info('Migrating database...');

        if (!$this->shell('php artisan migrate --force')) {
            $this->error('Database migration failed.');
            return;
        }

        $this->info("Installing required packages...");
        $this->info('This can take a minute...');

        if (!$this->shell('yarn add react-email-editor react-colorful recharts@^2.15.4 ua-parser-js cronstrue react-day-picker jszip react-turnstile @dnd-kit/core @dnd-kit/sortable @dnd-kit/utilities @types/md5 md5 react-icons@5.4.0 markdown-to-jsx@7.7.10 i18next-browser-languagedetector@7.2.1')) {
            $this->error('Installing packages failed.');
            return;
        }

        $this->info('Compile translations...');
        $this->command('php artisan language:compile');

        $this->info('Building panel assets...');
        $this->info('This can take a minute...');

        if (!$this->shell('yarn build:production')) {
            $this->error('Building panel assets failed.');
            return;
        }

        $this->info('Set permissions...');

        $this->command("chown -R www-data:www-data " . base_path() . "/*");
        $this->command("chown -R nginx:nginx " . base_path() . "/*");
        $this->command("chown -R apache:apache " . base_path() . "/*");

        $this->info('Optimize application...');

        $this->command('php artisan optimize:clear');
        $this->command('php artisan optimize');

        $this->info('Restarting workers...');

        $this->command('php artisan queue:restart');

        $this->line("\r\n ╭───────────────────────────────╮\r\n │ │\r\n │ ╭─╴ Theme installed ╶─╮ │\r\n │ ╰─╴ successfully ╶─╯ │\r\n │ │\r\n ╰───────────────────────────────╯\r\n ");
    }

    public function install()
    {
        $this->installOrUpdate();
    }

    private function uninstall()
    {
        $this->line("Uninstalling...");

        $this->command('php artisan down');

        $this->command('curl -L https://github.com/pterodactyl/panel/releases/latest/download/panel.tar.gz | tar -xzv');

        $this->command('chmod -R 755 storage/* bootstrap/cache');
        $this->command('composer install --no-dev --optimize-autoloader');

        $this->command('php artisan view:clear');
        $this->command('php artisan config:clear');
        $this->command('php artisan migrate --seed --force');

        $this->command('chown -R www-data:www-data ' . base_path() . '/*');
        $this->command('chown -R nginx:nginx ' . base_path() . '/*');
        $this->command('chown -R apache:apache ' . base_path() . '/*');

        $this->command('php artisan queue:restart');
        $this->command('php artisan up');
    }

    private function shell($cmd): bool
    {
        exec($cmd, $output, $code);

        return $code === 0;
    }

    private function command($cmd)
    {
        return exec($cmd);
    }
}
