<?php

namesspace Pterodactyl\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\File;
use Symfony\Component\Console\Formatter\OutputFormatterStyle;

class Arix extends Command
{
    protected $signature = 'arix {action?}';

    protected $description = 'All commands for Arix Theme for Pterodactyl.';

    public function handle()
    {
        $action = $this->argument('action');

        $title = new OutputFormatterStyle('#fff', null, ['bold']);
        $this->output->getFormatter()->setStyle('title', $title);

        $b = new OutputFormatterStyle(null, null, ['bold']);
        $this->output->getFormatter()->setStyle('b', $b);

        if ($action === null) {
            $this->line("
            <title>
            ░█████╗░██████╗░██╗██╗░░██╗
            ██╔══██╗██╔══██╗██║╚██╗██╔╝
            ███████║██████╔╝██║░╚███╔╝░
            ██╔══██║██╔══██╗██║░██╔██╗░
            ██║░░██║██║░░██║██║██╔╝╚██╗
            ╚═╝░░╚═╝╚═╝░░╚═╝╚═╝╚═╝░░╚═╝

           Thank you for purchasing Arix</title>

           > php artisan arix
           > php artisan arix install
           > php artisan arix uninstall
            ");
        } elseif ($action === 'install') {
            $this->install();
        } elseif ($action === 'uninstall') {
            $this->uninstall();
        } else {
            $this->error("Invalid action. Supported actions: install, uninstall");
            return 1;
        }

        return 0;
    }

    public function installOrUpdate()
    {
        // Automatically confirm dependencies (YES)

        foreach (['node', 'yarn', 'rsync'] as $bin) {
            exec('command -v ' . escapeshellarg($bin), $out, $code);

            if ($code !== 0) {
                $this->error("Required program not found: {$bin}. Install it and run again.");
                return 1;
            }
        }

        // Find available Arix versions

        $versions = File::directories(base_path('arix'));

        if (empty($versions)) {
            $this->error('No versions found in /arix directory.');
            return 1;
        }

        // Automatically select option 0 (first version)

        $version = basename($versions[0]);

        $this->info("Automatically selected Arix Theme {$version}...");
        $this->info("Installing Arix Theme {$version}...");

        if (!$this->shell("rsync -a " . escapeshellarg(base_path("arix/{$version}/")) . " " . escapeshellarg(base_path() . "/"))) {
            $this->error('Copying theme files failed.');
            return 1;
        }

        $directoryPath = app_path('Http/Controllers/Admin/Arix');

        File::makeDirectory($directoryPath, 0755, true, true);

        $this->info('Proceeding with the installation...');

        $this->info('Migrating database...');

        if (!$this->shell('php artisan migrate --force')) {
            $this->error('Database migration failed.');
            return 1;
        }

        $this->info('Installing required packages...');
        $this->info('This can take a minute...');

        if (!$this->shell('yarn add react-email-editor react-colorful recharts@^2.15.4 ua-parser-js cronstrue react-day-picker jszip react-turnstile @dnd-kit/core @dnd-kit/sortable @dnd-kit/utilities @types/md5 md5 react-icons@5.4.0 markdown-to-jsx@7.7.10 i18next-browser-languagedetector@7.2.1')) {
            $this->error('Installing packages failed.');
            return 1;
        }

        $this->info('Compile translations...');

        if (!$this->shell('php artisan language:compile')) {
            $this->error('Translation compilation failed.');
            return 1;
        }

        $this->info('Building panel assets...');
        $this->info('This can take a minute...');

        if (!$this->shell('yarn build:production')) {
            $this->error('Building panel assets failed.');
            return 1;
        }

        $this->info('Set permissions...');

        $this->shell('chown -R www-data:www-data ' . escapeshellarg(base_path()));
        $this->shell('chown -R nginx:nginx ' . escapeshellarg(base_path()));
        $this->shell('chown -R apache:apache ' . escapeshellarg(base_path()));

        $this->info('Optimize application...');

        if (!$this->shell('php artisan optimize:clear')) {
            $this->error('Optimize clear failed.');
            return 1;
        }

        if (!$this->shell('php artisan optimize')) {
            $this->error('Application optimization failed.');
            return 1;
        }

        $this->info('Restarting workers...');

        if (!$this->shell('php artisan queue:restart')) {
            $this->error('Queue restart failed.');
            return 1;
        }

        $this->line("
 ╭───────────────────────────────╮
 │                               │
 │       Theme installed         │
 │       successfully!           │
 │                               │
 ╰───────────────────────────────╯
        ");

        return 0;
    }

    public function install()
    {
        return $this->installOrUpdate();
    }

    private function uninstall()
    {
        $this->line("Uninstalling...");

        $commands = [
            'php artisan down',
            'curl -L https://github.com/pterodactyl/panel/releases/latest/download/panel.tar.gz | tar -xzv',
            'chmod -R 755 storage/* bootstrap/cache',
            'composer install --no-dev --optimize-autoloader',
            'php artisan view:clear',
            'php artisan config:clear',
            'php artisan migrate --seed --force',
            'php artisan queue:restart',
            'php artisan up',
        ];

        foreach ($commands as $command) {
            if (!$this->shell($command)) {
                $this->error("Command failed: {$command}");
                return 1;
            }
        }

        $this->shell('chown -R www-data:www-data ' . escapeshellarg(base_path()));

        $this->info('Uninstallation completed.');

        return 0;
    }

    private function shell($cmd): bool
    {
        $this->line("<fg=yellow>$ {$cmd}</>");

        passthru($cmd, $code);

        return $code === 0;
    }
}
