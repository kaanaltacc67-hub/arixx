
public function installOrUpdate()
{
    foreach (['node', 'yarn', 'rsync'] as $bin) {
        exec('command -v ' . $bin, $out, $code);
        if ($code !== 0) {
            $this->error("Required program not found: {$bin}. Install it and run again.");
            return;
        }
    }

    $version = '0';

    if (!File::isDirectory(base_path("arix/{$version}"))) {
        $this->error("Version 0 not found in arix directory.");
        return;
    }

    $this->info("Installing Arix Theme {$version}...");

    if (!$this->shell("rsync -a arix/{$version}/ ./")) {
        $this->error('Copying theme files failed.');
        return;
    }

    $directoryPath = app_path('Http/Controllers/Admin/Arix');
    File::makeDirectory($directoryPath, 0755, true, true);

    $this->info('Proceeding with the installation...');
    $this->info('Migrating database...');

    if (!$this->shell('php artisan migrate --force')) {
        $this->error('Database migration failed.');
        return;
    }

    $this->info("Installing required packages...");
    $this->info('This can take a minute...');

    if (!$this->shell('yarn add react-email-editor react-colorful recharts@^2.15.4 ua-parser-js cronstrue react-day-picker jszip react-turnstile @dnd-kit/core @dnd-kit/sortable @dnd-kit/utilities @types/md5 md5 react-icons@5.4.0 markdown-to-jsx@7.7.10 i18next-browser-languagedetector@7.2.1')) {
        $this->error('Installing packages failed.');
        return;
    }

    $this->info('Compile translations...');
    $this->command('php artisan language:compile');

    $this->info('Building panel assets...');
    $this->info('This can take a minute...');

    if (!$this->shell('yarn build:production')) {
        $this->error('Building panel assets failed.');
        return;
    }

    $this->info('Set permissions...');
    $this->command("chown -R www-data:www-data " . base_path() . "/*");
    $this->command("chown -R nginx:nginx " . base_path() . "/*");
    $this->command("chown -R apache:apache " . base_path() . "/*");

    $this->info('Optimize application...');
    $this->command('php artisan optimize:clear');
    $this->command('php artisan optimize');

    $this->info('Restarting workers...');
    $this->command('php artisan queue:restart');

    $this->line("\r\n ╭───────────────────────────────╮\r\n │ │\r\n │ ╭─╴ Theme installed ╶─╮ │\r\n │ ╰─╴ successfully ╶─╯ │\r\n │ │\r\n ╰───────────────────────────────╯\r\n ");
}
