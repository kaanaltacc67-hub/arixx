<?php

namespace Pterodactyl\Console\Commands;

use Illuminate\Console\Command;
use Symfony\Component\Console\Formatter\OutputFormatterStyle;
use Illuminate\Support\Facades\File;

class Arix extends Command
{
    protected $signature = 'arix {action?}';
    protected $description = 'All commands for Arix Theme for Pterodactyl.';

    public function handle()
    {
        $action = $this->argument('action');

        $title = new OutputFormatterStyle('#fff', null, ['bold']);
        $this->output->getFormatter()->setStyle('title', $title);

        $b = new OutputFormatterStyle(null, null, ['bold']);
        $this->output->getFormatter()->setStyle('b', $b);

        if ($action === null) {
            $this->line("
            <title>
            ░█████╗░██████╗░██╗██╗░░██╗
            ██╔══██╗██╔══██╗██║╚██╗██╔╝
            ███████║██████╔╝██║░╚███╔╝░
            ██╔══██╗██╔══██╗██║░██╔██╗░
            ██║░░██║██║░░██║██║██╔╝╚██╗
            ╚═╝░░╚═╝╚═╝░░╚═╝╚═╝╚═╝░░╚═╝

           Thank you for purchasing Arix</title>

           > php artisan arix
           > php artisan arix install
           > php artisan arix uninstall
            ");
        } elseif ($action === 'install') {
            $this->install();
        } elseif ($action === 'uninstall') {
            $this->uninstall();
        } else {
            $this->error("Invalid action. Supported actions: install, uninstall");
        }
    }

    public function installOrUpdate()
    {
        // Automatically answer YES.
        $this->info('Dependencies confirmation: YES');

        // Check dependencies.
        foreach (['node', 'yarn', 'rsync'] as $bin) {
            exec('command -v ' . escapeshellarg($bin), $output, $code);

            if ($code !== 0) {
                $this->error("Required program not found: {$bin}");
                return;
            }
        }

        // Arix directory.
        $arixPath = '/var/www/pterodactyl/arix';

        if (!File::isDirectory($arixPath)) {
            $this->error("Arix directory not found: {$arixPath}");
            return;
        }

        // Automatically find available versions.
        $versions = File::directories($arixPath);

        if (empty($versions)) {
            $this->error("No version directories found inside {$arixPath}");
            return;
        }

        // Sort versions naturally.
        sort($versions, SORT_NATURAL | SORT_FLAG_CASE);

        // Automatically select first version.
        $versionPath = $versions[0];
        $version = basename($versionPath);

        $this->info("Automatically selected version: {$version}");
        $this->info("Installing Arix Theme {$version}...");

        // Copy theme files.
        $copyCommand = 'rsync -a ' .
            escapeshellarg($versionPath . '/') .
            ' ' .
            escapeshellarg(base_path() . '/');

        if (!$this->shell($copyCommand)) {
            $this->error('Copying theme files failed.');
            return;
        }

        // Create controller directory.
        $directoryPath = app_path('Http/Controllers/Admin/Arix');

        File::makeDirectory($directoryPath, 0755, true, true);

        // Database migration.
        $this->info('Proceeding with installation...');
        $this->info('Migrating database...');

        if (!$this->shell('php artisan migrate --force')) {
            $this->error('Database migration failed.');
            return;
        }

        // Install required packages.
        $this->info('Installing required packages...');
        $this->info('This can take a minute...');

        $packages = 'yarn add react-email-editor react-colorful recharts@^2.15.4 ua-parser-js cronstrue react-day-picker jszip react-turnstile @dnd-kit/core @dnd-kit/sortable @dnd-kit/utilities @types/md5 md5 react-icons@5.4.0 markdown-to-jsx@7.7.10 i18next-browser-languagedetector@7.2.1';

        if (!$this->shell($packages)) {
            $this->error('Installing packages failed.');
            return;
        }

        // Compile translations.
        $this->info('Compile translations...');
        $this->command('php artisan language:compile');

        // Build panel assets.
        $this->info('Building panel assets...');
        $this->info('This can take a minute...');

        if (!$this->shell('yarn build:production')) {
            $this->error('Building panel assets failed.');
            return;
        }

        // Set permissions.
        $this->info('Set permissions...');

        $basePath = base_path();

        // Set the appropriate owner for your web server before running.
        $this->command('chown -R www-data:www-data ' . escapeshellarg($basePath));

        // Optimize application.
        $this->info('Optimizing application...');

        $this->command('php artisan optimize:clear');
        $this->command('php artisan optimize');

        // Restart workers.
        $this->info('Restarting workers...');

        $this->command('php artisan queue:restart');

        $this->line("
╭───────────────────────────────╮
│                               │
│       Theme installed         │
│       successfully!           │
│                               │
╰───────────────────────────────╯
");
    }

    public function install()
    {
        $this->installOrUpdate();
    }

    private function uninstall()
    {
        $this->line('Uninstalling...');

        $this->command('php artisan down');

        $this->command(
            'curl -L https://github.com/pterodactyl/panel/releases/latest/download/panel.tar.gz | tar -xzv'
        );

        $this->command('chmod -R 755 storage/* bootstrap/cache');

        $this->command('composer install --no-dev --optimize-autoloader');

        $this->command('php artisan view:clear');
        $this->command('php artisan config:clear');

        $this->command('php artisan migrate --seed --force');

        $basePath = base_path();

        $this->command('chown -R www-data:www-data ' . escapeshellarg($basePath));

        $this->command('php artisan queue:restart');
        $this->command('php artisan up');
    }

    private function shell($cmd): bool
    {
        exec($cmd, $output, $code);

        return $code === 0;
    }

    private function command($cmd)
    {
        exec($cmd, $output, $code);

        return $code;
    }
}